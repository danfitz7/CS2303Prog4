#ifndef PROG4_H
#define PROG4_H

//set to 0 to suppress debug output
#define DEBUG 0

#endif
